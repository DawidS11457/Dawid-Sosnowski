

//to play on the key A do this(using Jquery):
document.addEventListener('keydown', function (e) {
    if (e.keyCode == 65 || e.keyCode == 81 || e.keyCode == 90 ) {
        var audio = new Audio('list/boom.wav');
        audio.play();
        $('#boom').addClass('boom');
        setTimeout(() => {
            $('#boom').removeClass('boom');
        }, 200);
        return false;
    }
    if (e.keyCode == 87 || e.keyCode == 83 || e.keyCode == 88 ) {
        var audio = new Audio('list/clap.wav');
        audio.play();
        $('#clap').addClass('clap');
        setTimeout(() => {
            $('#clap').removeClass('clap');
        }, 200);
        return false;
    }
    if (e.keyCode == 69 || e.keyCode == 68|| e.keyCode == 67 ) {
        var audio = new Audio('list/hihat.wav');
        audio.play();
        $('#hihat').addClass('hihat');
        setTimeout(() => {
            $('#hihat').removeClass('hihat');
        }, 200);
        return false;
    }
    if (e.keyCode == 82 || e.keyCode == 70 || e.keyCode == 86 ) {
        var audio = new Audio('list/kick.wav');
        audio.play();
        $('#kick').addClass('kick');
        setTimeout(() => {
            $('#kick').removeClass('kick');
        }, 200);
        return false;
    }
    if (e.keyCode == 84 || e.keyCode == 71 || e.keyCode == 66 ) {
        var audio = new Audio('list/openhat.wav');
        audio.play();
        $('#openhat').addClass('openhat');
        setTimeout(() => {
            $('#openhat').removeClass('openhat');
        }, 200);
        return false;
    }
    if (e.keyCode == 89 || e.keyCode == 72 || e.keyCode == 78 ) {
        var audio = new Audio('list/ride.wav');
        audio.play();
        $('#ride').addClass('ride');
        setTimeout(() => {
            $('#ride').removeClass('ride');
        }, 200);
        return false;
    }
    if (e.keyCode == 85 || e.keyCode == 74 || e.keyCode == 77 ) {
        var audio = new Audio('list/snare.wav');
        audio.play();
        $('#snare').addClass('snare');
        setTimeout(() => {
            $('#snare').removeClass('snare');
        }, 200);
        return false;
    }
    if (e.keyCode == 73 || e.keyCode == 75 || e.keyCode == 188 ) {
        var audio = new Audio('list/tink.wav');
        audio.play();
        $('#tink').addClass('tink');
        setTimeout(() => {
            $('#tink').removeClass('tink');
        }, 200);
        return false;
    }
    if (e.keyCode == 79 || e.keyCode == 76 || e.keyCode == 190 ) {
        var audio = new Audio('list/tom.wav');
        audio.play();
        $('#tom').addClass('tom');
        setTimeout(() => {
            $('#tom').removeClass('tom');
        }, 200);
        return false;
    }

});