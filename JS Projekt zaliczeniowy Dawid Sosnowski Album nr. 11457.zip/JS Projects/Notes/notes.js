let today = new Date().toISOString().slice(0, 10);

var notes = [];

function loadAllNotes() {
    notes = JSON.parse(localStorage.getItem('notes'));
    if (notes === undefined || notes == null) {
        notes = [];
    }
}

function addNote() {
    notes.push({
        id: new Date().getTime(),
        title: document.getElementById('header-in').value,
        content: document.getElementById('content-in').value,
        data: today,
        color: document.getElementById('color-in').value
    });
    localStorage.setItem('notes', JSON.stringify(notes));
    display();
}
function deleteNote(id) {
    notes.forEach(note => {
        if (note.id == id) {
            notes.splice(notes.indexOf(note), 1);
        }
    });
    localStorage.setItem('notes', JSON.stringify(notes));
    display();
}
function display() {
    $('#notes').html('');
    notes.forEach(note => {
        $('#notes').append(`
            <div class="col-lg-6">
                <div class="card-body card">
                    <div class = "row">
                        <div class = "col-md-12">
                            <button style ="float:right;" class = "btn btn-danger" onclick="deleteNote(`+ note.id + `)">X</button>
                        </div>
                    </div>
                    <div class="card-body">
                        
                        <div class = "row">
                            <div class = "col-md-6"><hr class = "marking" color = "`+ note.color + `"></div>
                            <div class = "col-md-6" style = "text-align: right">`+ note.data + `</div>
                        </div>
                        <h5 class="card-title">` + note.title + `</h5>
                        <p class="card-text">` + note.content + `</p>
                    </div>
                </div>
            </div>
        `);
    });
}

loadAllNotes();
display();