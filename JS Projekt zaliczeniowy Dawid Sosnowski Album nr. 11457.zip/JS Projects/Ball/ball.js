var width = 14;
var height = 12;

var holeCount = 15;

var matrix;
var ball = $('ball');
var ballPosition = {
    w: 0,
    h: 0
}

function init() {
    $('#game').html('');
    createMatrix();
    $('#game').append(getStart(0, 0));
    $('#game').append(getEnd(width - 1, height - 1));
    $('#game').append(getBall());
    for (let i = 2; i < width - 2; i++) {
        $('#game').append(getHole(i, 0));
        $('#game').append(getHole(i, height - 1));
        matrix[0][i] = 1;
        matrix[height - 1][i] = 1;
    }
    for (let i = 2; i < height - 2; i++) {
        $('#game').append(getHole(0, i));
        $('#game').append(getHole(width - 1, i));
        matrix[i][0] = 1;
        matrix[i][width - 1] = 1;
    }
    generateHole();
    if (width - 1 == ballPosition.w && height - 1 == ballPosition.h) {
        gameWin();
    }
    if (matrix[ballPosition.h][ballPosition.w] == 1) {
        gameOwer();
    }
}

function createMatrix() {
    matrix = [];
    for (let i = 0; i < height; i++) {
        let row = [];
        for (let j = 0; j < width; j++) {
            row.push(0);
        }
        matrix.push(row);
    }
    matrix[0][0] = 2;
    matrix[height - 1][width - 1] = 3;
}

function generateHole() {
    let i = 0;
    while (i < holeCount) {
        let w = Math.floor(Math.random() * 12) + 1;
        let h = Math.floor(Math.random() * 10) + 1;
        if (matrix[h][w] == 0) {
            matrix[h][w] = 1;
            $('#game').append(getHole(w, h));
            i++;
        }
    }
}

function getHole(width, height) {
    let hole = $('<div class="hole"></div>');
    hole.css({ top: height * 50, left: width * 50, position: 'absolute' });
    return hole;
}

function getStart(width, height) {
    let hole = $('<div class="start-point"></div>');
    hole.css({ top: height * 50, left: width * 50, position: 'absolute' });
    return hole;
}

function getEnd(width, height) {
    let hole = $('<div class="end-point"></div>');
    hole.css({ top: height * 50, left: width * 50, position: 'absolute' });
    return hole;
}

function getBall() {
    let hole = $('<div class="ball"></div>');
    hole.css({ top: ballPosition.h * 50, left: ballPosition.w * 50, position: 'absolute' });
    return hole;
}

function moveLeft() {
    ballPosition.w--;
    if (ballPosition.w < 0) {
        ballPosition.w = 0
    }
    init();
}

function moveRight() {
    ballPosition.w++;
    if (ballPosition.w == width) {
        ballPosition.w = width - 1;
    }
    init();
}

function moveUp() {
    ballPosition.h--;
    if (ballPosition.h < 0) {
        ballPosition.h = 0
    }
    init();
}

function moveDown() {
    ballPosition.h++;
    if (ballPosition.h == height) {
        ballPosition.h = height - 1
    }
    init();
}

document.addEventListener('keydown', function (e) {
    if (e.keyCode == 65) {
        moveLeft();
    }
    if (e.keyCode == 87) {
        moveUp();
    }
    if (e.keyCode == 83) {
        moveDown();
    }
    if (e.keyCode == 68) {
        moveRight();
    }
});

function startGame() {
    ballPosition = {
        w: 0,
        h: 0
    }
    $('#game-ower').hide();
    $('#game-menu').hide();
    $('#game-win').hide();
    init();
}

function gameOwer() {
    $('#game-ower').show();
    $('#game-menu').show();
}

function gameWin() {
    $('#game-win').show();
    $('#game-menu').show();
}


